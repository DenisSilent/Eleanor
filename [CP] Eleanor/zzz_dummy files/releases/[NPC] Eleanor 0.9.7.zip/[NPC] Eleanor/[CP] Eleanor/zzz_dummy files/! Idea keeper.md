# Idea keeper

* for ideas, notes, etc. for NPC Eleanor

---

## Ideas

* ~~Eleanor's home~~
  * ~~Somewhere in the void~~
  * Access with 8 hearts event
* Accessable brand new map - the village where Eleanor is from
  * Located somewhere in the mountains
  * Access after 10? hearts event
    * --> change the 14h-p1 text
  * New NPCs with its lore?

## Improvements

* Page rewrite
  * More screenshots
  * Better text
  * More details
    * Includes more guides,...
* More content
* Leaving SVE as a requirement? We'll see...
* Better/more art!!!!!!!!!! (Will probably never improve X ....)

