
Guide (accurate for mod version 0.9.0 from 22.3.2025) below in the spoiler.

[spoiler]
    // 0hearts - Eleanor's introduction
    // Location: your farm
    // Trigger: Entering your farm after seeing itroduction event with Mr. Rasmodius.
    // Description: Eleanor introduces herself to the player, greeting them politely and explaining who she is and that she knows about you and Junimos.

    // 2hearts - Eleanor's nature admiring
    // Location: Forest
    // Trigger: Enter the Forest between 6:00 and 12:00.
    // Description: Eleanor is admiring nature when she notices the player. She greets them and asks if they like nature as well.

    // 4hearts - The book search
    // Location: Wizard's basement
    // Trigger: Enter the Wizard's basement after 18:00.
    // Description: Eleanor will be searching for a book when she notices the player. She asks them for help in finding it.

    // 7hearts - Check on Eleanor
    // Location: Forest
    // Trigger: Enter the Forest when it is raining.
    // Description: You and Eleanor are getting closer to each other.

    // 10 hearts - same as 14 hearts short event variants
    // SVE only version
    // Location: Wizard's Tower
    // Trigger: Entering the Wizard's Tower after reaching 10 hearts with Eleanor.
    // Description: Eleanor shares her history with the player, revealing her past and her connection to magic.
[/spoiler]
