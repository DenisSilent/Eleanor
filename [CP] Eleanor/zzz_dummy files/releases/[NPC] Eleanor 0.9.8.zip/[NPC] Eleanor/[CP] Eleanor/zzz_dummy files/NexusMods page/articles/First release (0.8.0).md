
Hi everyone,

thanks for looking at (and also maybe downloading) this mod!
If you want, tell me what are your opinions about my NPC Eleanor mod below!

Thanks!
Denis001 a.k.a. StrojvedouciDenis
